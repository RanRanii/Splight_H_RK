# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000000010000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000001000000F00000000000001` | `-2` | `-0` | `-2` |
| `1` | `0100000000000000` | `01000000` | `00100000` | `00100000` | `00000000` | `00000000` | `001000000F0000000000000100000000` | `-2` | `-2` | `-0` |
| `2` | `0000000001000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`DC81140A334D1B48`
- State B：`DC81140A334C1B48`
- State A Final：`3B8BB997EA0FDC02`
- State B Final：`3B8BB997EB0FDC02`
- Master Key A：`FED0DEB6EDE4AD63213522410F000000`
- Master Key B：`FED0DEB7EDE4AD732125224100000000`
- Master Key Difference：`0000000100000010001000000F000000`
- Concrete Replay：`PASS`
