# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`5`
- Weight：`8.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000100000000` | `00000001` | `00001000` | `00001000` | `00000000` | `00000000` | `00001000000100020010002001000200` | `-2` | `-2` | `-0` |
| `1` | `0000000000000001` | `00000000` | `00000000` | `00000002` | `00000002` | `00000002` | `00000002001000200100020000001000` | `-2` | `-2` | `-0` |
| `2` | `0000030000000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`536D3A9716B40E24`
- State B：`536D3A9616B40E24`
- State A Final：`ED5072330EB94EDE`
- State B Final：`ED5071330EB94EDE`
- Master Key A：`9E050D8CEC54C833E59CCFAFEDE61C58`
- Master Key B：`9E050D8CEC54C833F59CFFAFEDE41C5B`
- Master Key Difference：`00000000000000001000300000020003`
- Concrete Replay：`PASS`
