# 2-3-2 Em 概率不为 1 的排查记录

## 现象

在 `r0=2, rm=3, r1=2, rk_mode=rk-ladder` 下，截断模型输出：

```text
Number of common active S-boxes: 0 (state=0, key=0)
```

但 `--probtest t` 的 Em 中间相关密钥 boomerang switch 随机实验结果为：

```text
returned = 167 / 2^12
estimated_r = 0.040771484375
log2_r = -4.616296
```

这与“CAS=0 时 Em switch 概率应为 1”的直觉不一致。

## 已修正的问题

原先截断 boomerang 模型只把加密状态中的 16 个 S-box 计入 common active，没有显式输出和统计 key schedule 中的 key-core S-box。

现在 `rktruncboom.py` 已经增加：

```text
ks_common_r_0
ks_common_r_1
```

分别对应每个中间轮 key schedule 中第 3、7 个 key-core S-box 的上下共同活跃变量。

同时增加约束：

```text
upper_key_sbox + lower_key_sbox <= 1
```

因此中间密钥调度 S-box 不允许上下共同活跃，并且 key schedule common active 会计入总 CAS。当前 2-3-2 结果中：

```text
state common active = 0
key common active   = 0
total CAS           = 0
```

## 已修正的密钥状态固定点

`RKDiff` 中的 `master_key_diff` 是全局 `ks_0`。对于 lower 路径，Em 末端/E1 起点不是 `master_key_diff`，而是：

```text
ks_global_{r0+rm}
```

在 2-3-2 中即：

```text
ks_global_5 = 00000000000010000001000000100000
```

因此 `nabla_keydiff_backward` 现在固定：

```text
fixedVariables = { "ks_3": "00000000000010000001000000100000" }
```

而不是固定 lower 的 `master_key_diff`。

## 当前保存的 keydiff 调用结果

两个 Gurobi key schedule MILP 调用结果已经单独保存：

```text
delta_keydiff_forward.json
delta_keydiff_forward.txt
nabla_keydiff_backward.json
nabla_keydiff_backward.txt
```

其中当前结果为：

```text
delta forward:
ks_0 = 00000000000000000000100000000000
ks_1 = 00000000000010000000000000000000
ks_2 = 00001000000000000000000000000000
weight = 0

nabla backward:
ks_0 = 00001000000000000000000001000000
ks_1 = 00010000000000000100000000001000
ks_2 = 00100000010000000000100000010000
ks_3 = 00000000000010000001000000100000
weight = 2
```

## 为什么随机实验仍不为 1

当前 `probability_test.py` 的 `rkboomerang` 模式只固定 Em 起点的两个 128-bit key-state 差分：

```text
delta_key_diff
nabla_key_diff
```

然后对随机 key state 做：

```text
Kb = Ka xor delta_key_diff
Kc = Ka xor nabla_key_diff
Kd = Kb xor nabla_key_diff
```

随后调用真实 key schedule 生成每一轮 round key。

这意味着实验没有条件化到 `keydiff.py` 求出的完整 key schedule 差分路径。只要中间 key schedule 中存在单侧活跃 key-core S-box，随机 key 经过 S-box 后的输出差分就不一定等于 MILP 选中的输出差分。

因此当前实验测到的是：

```text
Em switch 成功概率 × key schedule 差分路径被随机 key 满足的概率
```

而不是只测试“在给定 keydiff MILP 路径条件下”的纯 Em switch 概率。

本次 2-3-2 的 `nabla_keydiff_backward` weight 为 2，说明 key schedule 中存在非零概率的 S-box 差分转移。这个概率会进入当前未条件化随机实验，所以即使 state/key 的 common active 都为 0，实测值仍可能小于 1。

## 后续建议

如果目标是验证 Hadipour 中的纯 switch 概率 `r`，概率测试需要改为条件化实验：

```text
固定或采样满足 delta_key_milp.states 的 key pair
固定或采样满足 nabla_key_milp.states 的 key pair
再测试 Em 的 boomerang switch 是否返回
```

或者实现一个“按每轮 round-key 差分序列直接测试”的条件化版本。否则当前 `rkboomerang` 随机实验会把 key schedule 的单侧差分概率也乘进去。
