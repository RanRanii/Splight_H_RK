# 2-3-2 Em 概率偏大/不匹配问题排查汇总

本文只做排查总结，不修改搜索代码。

## 当前观测

当前参数：

```text
r0 = 2
rm = 3
r1 = 2
rk_mode = rk-ladder
probtest = t
```

搜索结果显示：

```text
common active : 0
state/key     : 0/0
```

但 Em 相关密钥 boomerang switch 实验为：

```text
returned = 167 / 2^12
estimated_r = 0.040771484375
log2_r = -4.616296
```

这说明当前实验测到的值不是单纯的 Hadipour 中间 switch 概率 `r`，至少混入了其它约束的满足概率。

## 已保存的 keydiff 调用

两个 key schedule MILP 的调用结果已单独保存，便于检查：

```text
delta_keydiff_forward.json
delta_keydiff_forward.txt
nabla_keydiff_backward.json
nabla_keydiff_backward.txt
```

当前结果为：

```text
delta forward:
fixed ks_0 = 00000000000000000000100000000000
ks_0       = 00000000000000000000100000000000
ks_1       = 00000000000010000000000000000000
ks_2       = 00001000000000000000000000000000
weight     = 0

nabla backward:
fixed ks_3 = 00000000000010000001000000100000
ks_0       = 00001000000000000000000001000000
ks_1       = 00010000000000000100000000001000
ks_2       = 00100000010000000000100000010000
ks_3       = 00000000000010000001000000100000
weight     = 2
```

这里 `nabla backward` 的固定点已经使用 lower 具体路径的：

```text
ks_global_{r0+rm} = ks_global_5
```

而不是 lower 的 `master_key_diff = ks_global_0`。

## 已排除的问题

### 轮常数起点不是本例主因

我对同一组输入差分、输出差分、`delta_key_diff`、`nabla_key_diff` 做了两个临时实验：

```text
round_const_start = 0
round_const_start = 2
```

结果完全一致：

```text
right = 167 / 4096
prob  = 0.040771484375
log2  = -4.616296
```

因此本例中 Em 概率不匹配不是由 `round_const_start` 偏移直接导致的。

## 已确认的主要问题

### 1. 当前 rkboomerang 实验是未条件化实验

`probability_test.py` 的 `rkboomerang` 模式只固定 Em 起点的两个 128-bit key-state 差分：

```text
delta_key_diff
nabla_key_diff
```

然后随机取：

```text
Ka
Kb = Ka xor delta_key_diff
Kc = Ka xor nabla_key_diff
Kd = Kb xor nabla_key_diff
```

再让四个 key state 经过真实 key schedule。

这没有强制四条 key schedule 在每一轮都满足 `keydiff.py` 的 MILP 路径。尤其是 key-core 中存在 S-box 时，随机 key pair 经过 S-box 后未必落在 MILP 选择的输出差分上。

因此当前实验测量的是：

```text
key schedule 差分路径被随机 key 满足的概率
乘以
给定这些随机 round key 后的 Em boomerang 返回概率
```

而不是纯粹的 Hadipour switch 概率。

### 2. nabla key schedule 路径本身已有非零概率损失

对当前 `nabla_keydiff_backward` 路径做临时随机检查：

```text
目标路径:
ks_0 = 00001000000000000000000001000000
ks_1 = 00010000000000000100000000001000
ks_2 = 00100000010000000000100000010000
ks_3 = 00000000000010000001000000100000

随机样本数 = 4096
命中数     = 1002
命中率     = 0.24462890625
log2      = -2.031333
```

这与 `nabla_key_milp.weight = 2` 基本一致。也就是说，仅 key schedule 路径本身就约有 `2^-2` 的概率损失。

当前 Em 实测 `2^-4.616` 中，至少有一部分来自这个 key schedule 路径概率，而不是来自 common active S-box。

### 3. keydiff 是单边路径，不是四密钥联合路径

当前 `keydiff.py` 分别求：

```text
delta_key_milp
nabla_key_milp
```

它们是两个独立 MILP。`rkboomerang` 实验中实际使用四个 key：

```text
Ka
Kb = Ka xor delta
Kc = Ka xor nabla
Kd = Ka xor delta xor nabla
```

但当前没有一个联合 MILP 同时约束：

```text
Ka -> Kb 的 delta key schedule 路径
Ka -> Kc 的 nabla key schedule 路径
Kb -> Kd 的 nabla key schedule 路径
Kc -> Kd 的 delta key schedule 路径
```

因此即使两个单边 keydiff 路径都可行，它们也不一定能在同一个随机 `Ka` 上联合满足。这会进一步影响 Em 实测概率。

### 4. 截断模型中的 key schedule 只表达活跃性，不表达 DDT 权重

`rktruncdiff.py` 的截断 key schedule 中，key-core S-box 位置目前用的是活跃性等式：

```text
input active = output active
```

这对于截断活跃传播是合理的，但它没有表达具体 S-box DDT 概率。具体概率只在 `rkdiff.py` 和 `keydiff.py` 的 bit-level DDT MILP 中出现。

因此截断阶段得到：

```text
key common active = 0
```

只能说明上下 key-core S-box 没有共同活跃，不能说明单侧 key-core S-box 的概率损失为 0。

### 5. 当前 Em 概率测试没有使用中间每轮 round-key 差分序列

`rkboomerang` 实验只接收：

```text
delta_key_diff
nabla_key_diff
```

它不接收，也不检查：

```text
delta_key_milp.states
nabla_key_milp.states
每轮 round key diff
每轮 key-core S-box 选择的 DDT 转移
```

因此它不能区分：

```text
给定 key schedule 差分路径条件下的 Em switch 概率
```

和：

```text
随机 key 自动满足这些 key schedule 差分条件的概率
```

这两者是不同的实验对象。

## 可能但暂未定论的问题

### 1. delta/nabla 的中间状态路径未具体实例化

当前 `rkboom.py` 的具体差分路径仍主要实例化：

```text
upper: E0
lower: E1
```

Em 中间部分只使用边界差分：

```text
Delta = upper x_r0
nabla = lower x_0
```

没有实例化完整的：

```text
E0 + Em
Em + E1
```

因此 Em 内部的 state 侧具体差分路径没有被固定。CAS=0 是截断条件，不是一个完整具体路径条件。

### 2. common active 统计只统计“共同活跃”，不统计“单侧活跃”

Hadipour switch 上界常按 common active S-box 估算，但相关密钥环境下，单侧 key schedule S-box 的概率损失也会进入未条件化实验。

当前报告中：

```text
state/key common active = 0/0
```

并不意味着：

```text
state/key 单侧活跃 S-box = 0
```

例如当前 `nabla_key_milp.weight = 2` 就说明存在单侧 key S-box 概率损失。

### 3. 当前实验值可能不是“太大”，而是口径不同

如果理论上期望的是纯 switch 概率 `r`，那么 CAS=0 时可期待 `r` 接近 1。

但当前实验口径包含 key schedule 路径概率和未固定中间具体路径的概率，得到 `2^-4.616` 并不直接说明 switch 模型本身错误，而是说明实验统计口径不是纯 `r`。

## 建议的下一步验证方式

### 方案 A：条件化 key schedule 路径后再测试 Em

实现一个新的概率测试模式，要求采样时只接受满足以下路径的 key：

```text
delta_key_milp.states
nabla_key_milp.states
```

然后再统计 boomerang 返回率。这样得到的才更接近：

```text
给定 key schedule 差分路径条件下的 Em switch 概率
```

缺点是拒绝采样可能较慢，尤其 key path weight 较大时。

### 方案 B：直接按每轮 round-key 差分序列测试 Em

把 Em 实验从“输入 128-bit key diff”改成“输入每轮 round-key diff”：

```text
round_key_delta[0..rm-1]
round_key_nabla[0..rm-1]
```

这样可以绕开 key schedule 随机满足概率，只测试状态层面的 Em switch。

缺点是这不再是完整真实 related-key schedule 实验，而是条件化后的 round-key 实验。

### 方案 C：建立四密钥联合 key schedule MILP

构造联合模型，同时约束四条 key schedule：

```text
Ka, Kb, Kc, Kd
```

并固定两类差分：

```text
Ka xor Kb = delta
Ka xor Kc = nabla
Kb xor Kd = nabla
Kc xor Kd = delta
```

该模型可以检查 delta/nabla 两条 keydiff 路径是否能在同一个四密钥结构中同时成立，并输出可用于实验的条件。

### 方案 D：分开报告两个概率

建议以后输出中明确区分：

```text
key schedule path probability
conditional Em switch probability
unconditional rkboomerang probability
```

当前 `0.040771484375` 更接近第三类，而不是第二类。

## 当前结论

当前 2-3-2 结果中，`state/key common active = 0/0` 已经确认。但 Em 实测不为 1，主要不是 common active 统计遗漏造成的，而是概率测试口径问题：

```text
当前 rkboomerang 实验没有条件化 keydiff MILP 每轮路径，
所以会把 key schedule 单侧 S-box 差分概率和中间具体路径概率一并统计进去。
```

因此，若后续要验证 Hadipour 公式中的纯 Em switch 概率，应优先实现“条件化 key schedule 路径”的测试模式，或实现“按每轮 round-key 差分序列”的条件化 Em 实验。
