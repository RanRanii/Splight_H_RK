# Full Boomerang Exact Verification

- SMT status: `UNSAT`
- Concrete replay: `NOT_RUN`
- Rounds: `2-3-2`
- Elapsed seconds: `0.010705`
- Meaning: SAT plus replay PASS proves existence of a compatible real four-key/data quartet; it does not prove probability.
