# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`2.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `000C000000000000` | `00040000` | `40000000` | `40000000` | `00000000` | `00000000` | `40000000000000040000000000000000` | `-2` | `-2` | `-0` |
| `1` | `00000000000C0000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000000000000000000040000000` | `-0` | `-0` | `-0` |
| `2` | `0C00000000000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`F5A6F30B4A3CC0B1`
- State B：`F5AAF30B4A3CC0B1`
- State A Final：`7B97676AD8965202`
- State B Final：`7797676AD8965202`
- Master Key A：`B1A009AE6D465FB56B59050000000000`
- Master Key B：`B1A009AE2D465FB56B59050400000000`
- Master Key Difference：`00000000400000000000000400000000`
- Concrete Replay：`PASS`
