# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`8`
- Weight：`6.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0200000000000000` | `02000000` | `00200000` | `00200000` | `00000000` | `00000000` | `00200000010004001000400000010005` | `-6` | `-2` | `-4` |
| `1` | `0000000002000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`73BBABB000000000`
- State B：`71BBABB000000000`
- State A Final：`108A489673BBABB0`
- State B Final：`108A489671BBABB0`
- Master Key A：`336068399DD5B06D9F1C845AFA05D64F`
- Master Key B：`3365683D9D95B02D9F1C845AFA05D64F`
- Master Key Difference：`00050004004000400000000000000000`
- Concrete Replay：`PASS`
