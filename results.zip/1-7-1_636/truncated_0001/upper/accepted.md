# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000200002000` | `00000002` | `00002000` | `00000000` | `00002000` | `00002000` | `0000000000000000000000000000F000` | `-4` | `-4` | `-0` |
| `1` | `0000000000000002` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`4399B7AA00022000`
- State B：`4399B7A800020000`
- State A Final：`BA5BBBBB4399B7AA`
- State B Final：`BA5BBBBB4399B7A8`
- Master Key A：`F77C98AE000D40000000000000000000`
- Master Key B：`F77C68AE000240000000000000000000`
- Master Key Difference：`0000F000000F00000000000000000000`
- Concrete Replay：`PASS`
