# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0002000020000000` | `00020000` | `20000000` | `00000000` | `20000000` | `20000000` | `0000000000000000000000000F000000` | `-4` | `-4` | `-0` |
| `1` | `0000000000020000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`F348321C280000A0`
- State B：`F34A321C080000A0`
- State A Final：`B8BAE3DBF348321C`
- State B Final：`B8BAE3DBF34A321C`
- Master Key A：`ED61EFFF825000200000000000000000`
- Master Key B：`E261EFFF725000200000000000000000`
- Master Key Difference：`0F000000F00000000000000000000000`
- Concrete Replay：`PASS`
