# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`6`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0008000000000000` | `00080000` | `80000000` | `80008000` | `00008000` | `0000A000` | `80008000000000080000008000000800` | `-4` | `-4` | `-0` |
| `1` | `00A0000000080000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`4735AAF000008000`
- State B：`473DAAF000008000`
- State A Final：`B4B863574735AAF0`
- State B Final：`B4186357473DAAF0`
- Master Key A：`27CEB4FE6E623CFB00676A00DB9B9000`
- Master Key B：`27CEB4FE6E623CFB00676A005B9B9000`
- Master Key Difference：`00000000000000000000000080000000`
- Concrete Replay：`PASS`
