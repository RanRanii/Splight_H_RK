# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`5`
- Weight：`0.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000001000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000000D00030040007004000700` | `-0` | `-0` | `-0` |
| `1` | `0000000100000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`3B09707F00000000`
- State B：`3B09707F01000000`
- State A Final：`B1BDBBCB3B09707F`
- State B Final：`B1BDBBCA3B09707F`
- Master Key A：`27A9468995C44B1B4F02B100C876E6F3`
- Master Key B：`27A9468995C44B1B0F02C100C87CE6F4`
- Master Key Difference：`000000000000000040007000000A0007`
- Concrete Replay：`PASS`
