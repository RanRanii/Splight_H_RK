# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000200002000` | `00000002` | `00002000` | `00000000` | `00002000` | `00002000` | `0000000000000000000000000F000000` | `-4` | `-4` | `-0` |
| `1` | `0000000000000002` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`6AFF52E100802000`
- State B：`6AFF52E300800000`
- State A Final：`B55BBB8B6AFF52E1`
- State B Final：`B55BBB8B6AFF52E3`
- Master Key A：`B1F110C4F0C20C000000000000000000`
- Master Key B：`BEF110C400C20C000000000000000000`
- Master Key Difference：`0F000000F00000000000000000000000`
- Concrete Replay：`PASS`
