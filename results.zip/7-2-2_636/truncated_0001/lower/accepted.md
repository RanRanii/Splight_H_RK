# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`9`
- Weight：`2.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000100000000` | `00000003` | `00003000` | `00003000` | `00000000` | `00000000` | `000030000003000000D000000B000200` | `-2` | `-2` | `-0` |
| `1` | `0000000000000001` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `0000000000D000000B00020000003000` | `-0` | `-0` | `-0` |
| `2` | `0000010000000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`5A0304037D8A9052`
- State B：`5A0304027D8A9052`
- State A Final：`C107B5FD5399B89F`
- State B Final：`C107B4FD5399B89F`
- Master Key A：`55EA4D90412636F45AB5D0B1E29080A6`
- Master Key B：`558A4DC0412631F4EAB5C0B1E29180A0`
- Master Key Difference：`0060005000000700B000100000010006`
- Concrete Replay：`PASS`
