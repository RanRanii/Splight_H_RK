# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`7`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000900000000` | `0000000A` | `0000A000` | `2000A000` | `20000000` | `60000000` | `2000A000000A00000020000002000000` | `-4` | `-4` | `-0` |
| `1` | `0000006000000009` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`4F60218300000000`
- State B：`4F60218A00000000`
- State A Final：`B3C862264F602183`
- State B Final：`B3C862464F60218A`
- Master Key A：`580F0BAB48EDA08F4BB4A13751A6F780`
- Master Key B：`580FABAB48E7A08F4BB4A13751A6F780`
- Master Key Difference：`0000A000000A00000000000000000000`
- Concrete Replay：`PASS`
