# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`6.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000200002000` | `00000002` | `00002000` | `00000000` | `00002000` | `00002000` | `000000000000000000000000000000F2` | `-6` | `-4` | `-2` |
| `1` | `0000000000000002` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`E2ECAB1102002000`
- State B：`E2ECAB1302000000`
- State A Final：`AB55CF3BE2ECAB11`
- State B Final：`AB55CF3BE2ECAB13`
- Master Key A：`BFFAED0100200F600000000000000000`
- Master Key B：`BFFAEDF3002000400000000000000000`
- Master Key Difference：`000000F200000F200000000000000000`
- Concrete Replay：`PASS`
