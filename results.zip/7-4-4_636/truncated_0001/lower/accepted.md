# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`11`
- Weight：`8.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `000D000D00000000` | `00040004` | `40004000` | `40004000` | `00000000` | `00000000` | `40004000000400040040004004000400` | `-4` | `-4` | `-0` |
| `1` | `00000000000D000D` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000004000400400040040004000` | `-0` | `-0` | `-0` |
| `2` | `0D000D0000000000` | `04000400` | `00400040` | `00400040` | `00000000` | `00000000` | `00400040040004004000400000000000` | `-4` | `-4` | `-0` |
| `3` | `000000000D000D00` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000400040000000000000400040` | `-0` | `-0` | `-0` |
| `4` | `000D000D00000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`443FB3CE31BF4C32`
- State B：`4432B3C331BF4C32`
- State A Final：`AC340C1522205CBD`
- State B Final：`AC390C1822205CBD`
- Master Key A：`44D8B4ED0C3518A8D03D688E1D7214CE`
- Master Key B：`44D8B4ED0C3118ACD03D688E137210CE`
- Master Key Difference：`0000000000040004000000000E000400`
- Concrete Replay：`PASS`
