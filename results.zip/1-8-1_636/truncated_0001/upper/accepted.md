# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`6.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0002000020000000` | `00020000` | `20000000` | `00000000` | `20000000` | `20000000` | `00000000000000000000000000020000` | `-6` | `-4` | `-2` |
| `1` | `0000000000020000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`288ADDEF20080C40`
- State B：`2888DDEF00080C40`
- State A Final：`6A4BACFF288ADDEF`
- State B Final：`6A4BACFF2888DDEF`
- Master Key A：`FEF32EEE102000300000000000000000`
- Master Key B：`FEF12EEE100000300000000000000000`
- Master Key Difference：`00020000002000000000000000000000`
- Concrete Replay：`PASS`
