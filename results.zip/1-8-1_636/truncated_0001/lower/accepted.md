# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`9`
- Weight：`6.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000010000000000` | `00000300` | `00000030` | `00000030` | `00000000` | `00000000` | `000000300A000100100010000001000A` | `-6` | `-2` | `-4` |
| `1` | `0000000000000100` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`A3040F2900000000`
- State B：`A3040E2900000000`
- State A Final：`66CC6B66A3040F29`
- State B Final：`66CC6B66A3040E29`
- Master Key A：`4CAC5EEEF7D5F2BADF1310103A14C212`
- Master Key B：`4CAC5EEEF7D5F2BADF0310103014C212`
- Master Key Difference：`0000000000000000001000000A000000`
- Concrete Replay：`PASS`
