# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000000020000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000002000000200000000002000` | `-0` | `-0` | `-0` |
| `1` | `0200000000000000` | `02000000` | `00200000` | `00200000` | `00000000` | `00000000` | `00200000020000000000200000000000` | `-2` | `-2` | `-0` |
| `2` | `0000000002000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000000020000000000000200000` | `-0` | `-0` | `-0` |
| `3` | `0000000200000000` | `00000002` | `00002000` | `00002000` | `00000000` | `00000000` | `00002000000000000020000000000000` | `-2` | `-2` | `-0` |
| `4` | `0000000000000002` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`4CEE1ECCA9730044`
- State B：`4CEE1ECCA9710044`
- State A Final：`A2D061F8A6BEDD3A`
- State B Final：`A2D061F8A6BEDD38`
- Master Key A：`C3314CE6CA78FE0B50A641C7B47268BC`
- Master Key B：`C3316CE6CA7AFE0B508641C7B67268BC`
- Master Key Difference：`00002000000200000020000002000000`
- Concrete Replay：`PASS`
