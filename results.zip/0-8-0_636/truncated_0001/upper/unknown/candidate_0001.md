# 上路径 Exact Candidate 0001

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`ERROR`
- Round Offset：`0`
- 主密钥输入差分：`0000000000000000000000000000000F`
- Weight：`0.0`
- 原因：`ValueError: rounds must be a positive integer`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `000000000000000F` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |
