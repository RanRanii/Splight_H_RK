# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`11`
- Weight：`10.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000000000009` | `00000000` | `00000000` | `000A0000` | `000A0000` | `00020000` | `000A0000000000A000000A000000A000` | `-2` | `-2` | `-0` |
| `1` | `0200090000000000` | `02000A00` | `002000A0` | `002000A0` | `00000000` | `00000000` | `002000A000000A000000A000000A0000` | `-6` | `-4` | `-2` |
| `2` | `0000000002000900` | `00000000` | `00000000` | `02000000` | `02000000` | `06000000` | `020000000000A000000A0000002000A0` | `-2` | `-2` | `-0` |
| `3` | `0009000400000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`101D1CE06280DB46`
- State B：`101D1CE06280DB4F`
- State A Final：`C6E954A1C3CC9943`
- State B Final：`C6E054A5C3CC9943`
- Master Key A：`7B7ADD016A4E11783A28C9CD06605861`
- Master Key B：`7B7ADD016A4E11D83A28C9CD0660F861`
- Master Key Difference：`00000000000000A0000000000000A000`
- Concrete Replay：`PASS`
