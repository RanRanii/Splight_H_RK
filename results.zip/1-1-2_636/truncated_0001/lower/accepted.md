# 下路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`2`
- Weight：`2.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 下具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `0000000001000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000000030000000000000000000` | `-0` | `-0` | `-0` |
| `1` | `0000000100000000` | `00000003` | `00003000` | `00003000` | `00000000` | `00000000` | `00003000000000000000000000000000` | `-2` | `-2` | `-0` |
| `2` | `0000000000000001` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`3709117B1C5F612C`
- State B：`3709117B1D5F612C`
- State A Final：`258A9A2C2D000AE2`
- State B Final：`258A9A2C2D000AE3`
- Master Key A：`00602010E3E327EECFA07EF1FDEDEFFB`
- Master Key B：`00601010E3E027EECFA07EF1FDEDEFFB`
- Master Key Difference：`00003000000300000000000000000000`
- Concrete Replay：`PASS`
