# 上路径 Exact Accepted Candidate

- Truncated Path ID：`1`
- Candidate ID：`1`
- SMT 状态：`SAT`
- Concrete Replay：`PASS`
- Round Offset：`0`
- Weight：`4.0`
- Previous Truncated Paths：`0`
- Rejected Concrete Candidates：`0`

## 上具体相关密钥差分路径

| Rounds | x | y | l | RK | ak | z | KS | pr | rw | kw |
|---:|---|---|---|---|---|---|---|---|---|---|
| `0` | `000000000F000000` | `00000000` | `00000000` | `00000000` | `00000000` | `00000000` | `000000000000F000FFFFFFFFFFF4FFF4` | `-4` | `-0` | `-4` |
| `1` | `0000000F00000000` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` | `none` |

## Real Witness

- State A：`48F0780320000000`
- State B：`48F078032F000000`
- State A Final：`635B0E2048F07803`
- State B Final：`635B0E2F48F07803`
- Master Key A：`02112014EFFFFF3F0000E000FEFEEFFE`
- Master Key B：`FDE5DFE010C000000000100001011001`
- Master Key Difference：`FFF4FFF4FF3FFF3F0000F000FFFFFFFF`
- Concrete Replay：`PASS`
